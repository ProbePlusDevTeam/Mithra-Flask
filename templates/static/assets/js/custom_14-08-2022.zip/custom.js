function coordinatorEditEnable(){
  var x = document.getElementById("editEnable");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }

  var fname = document. getElementById("editcofirst_name"). disabled;
  var lname = document. getElementById("editcolast_name"). disabled;
  var number = document. getElementById("editconumber"). disabled;
  var email = document. getElementById("editcoemail"). disabled;
  var age = document. getElementById("editcoage"). disabled;
  var gender = document. getElementById("editcogender"). disabled;

  if (fname) {
  document. getElementById("editcofirst_name"). disabled = false;
  }
  else {
  document. getElementById("editcofirst_name"). disabled = true;
  }

  if (lname) {
  document. getElementById("editcolast_name"). disabled = false;
  }
  else {
  document. getElementById("editcolast_name"). disabled = true;
  }

  if (number) {
  document. getElementById("editconumber"). disabled = false;
  }
  else {
  document. getElementById("editconumber"). disabled = true;
  }

  if (email) {
  document. getElementById("editcoemail"). disabled = false;
  }
  else {
  document. getElementById("editcoemail"). disabled = true;
  }

  if (age) {
  document. getElementById("editcoage"). disabled = false;
  }
  else {
  document. getElementById("editcoage"). disabled = true;
  }

  if (gender) {
  document. getElementById("editcogender"). disabled = false;
  }
  else {
  document. getElementById("editcogender"). disabled = true;
  }
}

function investigatorEditEnable(){
var x = document.getElementById("editinEnable");
if (x.style.display === "block") {
  x.style.display = "none";
} else {
  x.style.display = "block";
}
var fname = document. getElementById("editinfirst_name"). disabled;
var lname = document. getElementById("editinlast_name"). disabled;
var number = document. getElementById("editinnumber"). disabled;
var email = document. getElementById("editinemail"). disabled;
var age = document. getElementById("editinage"). disabled;
var gender = document. getElementById("editingender"). disabled;

if (fname) {
document. getElementById("editinfirst_name"). disabled = false;
}
else {
document. getElementById("editinfirst_name"). disabled = true;
}


if (lname) {
document. getElementById("editinlast_name"). disabled = false;
}
else {
document. getElementById("editinlast_name"). disabled = true;
}

if (number) {
document. getElementById("editinnumber"). disabled = false;
}
else {
document. getElementById("editinnumber"). disabled = true;
}

if (email) {
document. getElementById("editinemail"). disabled = false;
}
else {
document. getElementById("editinemail"). disabled = true;
}

if (age) {
document. getElementById("editinage"). disabled = false;
}
else {
document. getElementById("editinage"). disabled = true;
}

if (gender) {
document. getElementById("editingender"). disabled = false;
}
else {
document. getElementById("editingender"). disabled = true;
}

}



function researcherEditEnable(){
var x = document.getElementById("editreEnable");
if (x.style.display === "block") {
  x.style.display = "none";
} else {
  x.style.display = "block";
}
var fname = document. getElementById("editrefirst_name"). disabled;
var lname = document. getElementById("editrelast_name"). disabled;
var number = document. getElementById("editrenumber"). disabled;
var email = document. getElementById("editreemail"). disabled;
var age = document. getElementById("editreage"). disabled;
var gender = document. getElementById("editregender"). disabled;

if (fname) {
document. getElementById("editrefirst_name"). disabled = false;
}
else {
document. getElementById("editrefirst_name"). disabled = true;
}


if (lname) {
document. getElementById("editrelast_name"). disabled = false;
}
else {
document. getElementById("editrelast_name"). disabled = true;
}

if (number) {
document. getElementById("editrenumber"). disabled = false;
}
else {
document. getElementById("editrenumber"). disabled = true;
}

if (email) {
document. getElementById("editreemail"). disabled = false;
}
else {
document. getElementById("editreemail"). disabled = true;
}

if (age) {
document. getElementById("editreage"). disabled = false;
}
else {
document. getElementById("editreage"). disabled = true;
}

if (gender) {
document. getElementById("editregender"). disabled = false;
}
else {
document. getElementById("editregender"). disabled = true;
}

}


function enableEditList(name){
var btnId = name
// alert(name)
var a = document.getElementById("editB"+name).getAttribute('value');
var x = document.getElementById("side_edit"+name);
var y = document.getElementById("full_edit"+name);
var z = document.getElementById("loc-edit-dis"+name);
// alert(a)
if(name == a){
  // alert("aaa")
  if (x.style.display === "block") {
    x.style.display = "none";
    y.style.display="block";
    z.style.display="none"; 
  } else {
    x.style.display = "block";
    y.style.display="none";
    z.style.display="block"
  }
}
else if(name != a){
  x.style.display = "none";
  y.style.display="none";
  z.style.display="none"; 
}


}

function addMoreSurvey(){
  $('.subDiv').parent('div.parentDiv').append($('.parentDiv').children('div:first').html());
}

function addMoreQuesOptions(){
$('.echildQues').parent('div.eparentQues').append($('.eparentQues').children('div:first').html());
$('.kchildQues').parent('div.kparentQues').append($('.kparentQues').children('div:first').html());

}


function viewQuesOptions1(){
// alert("aaa")
var single_q = document.getElementById("single_q").value;
var parentQues = document.getElementById("parent_all_ques")

// var multiple_q = document.getElementById("multiple_q").value;
// var text_q = document.getElementById("text_q").value;
// // var date_q = document.getElementById("date_q").value;
// // var numeric_q = document.getElementById("numeric_q").value;
// var opt_e = document.getElementById("opt2_e")
// var w_e = document.getElementById("w_e")

if (single_q == "single") {
  parentQues.style.display = "block";
  // opt_e.style.display ="none"
} 
// if("multiple"){
//   parentQues.style.display = "block";
// }
// if("text"){
//   alert("aaa")
//   parentQues.style.display = "none";
// }
// if(value == "text"){
//   parentQues.style.display = "none";
// }
// if(value == "text"){
//   parentQues.style.display = "none";
// }


}

function viewQuesOptions2(){
var multiple_q = document.getElementById("multiple_q").value;
var parentQues = document.getElementById("parent_all_ques")

if (multiple_q == "multiple" ) {
  parentQues.style.display = "block";
} 

}

function viewQuesOptions3(){

var text_q = document.getElementById("text_q").value;
var parentQues = document.getElementById("parent_all_ques")

if (text_q == "text" ) {
  parentQues.style.display = "none";
} 

}

function viewQuesOptions4(){

var date_q = document.getElementById("date_q").value;
var parentQues = document.getElementById("parent_all_ques")

if (date_q == "date" ) {
  parentQues.style.display = "none";
} 

}

function viewQuesOptions5(){

var numeric_q = document.getElementById("numeric_q").value;
var parentQues = document.getElementById("parent_all_ques")

if (numeric_q == "numeric" ) {
  parentQues.style.display = "none";
} 

}


// $(function() {
//   $( "#dob" ).datepicker({  maxDate: new Date() });
//  });




// ====================== coordinator functions ====================

function addCoordinator(){

// alert("fun") 

var firstName = document.getElementById("firstName").value
var lastName = document.getElementById("lastName").value
var fullName = firstName +" "+ lastName
var gender = document.querySelector('input[name="gender"]:checked').value;
var age = document.getElementById("dob").value
var number = document.getElementById("phone").value
var email = document.getElementById("email").value
var username = document.getElementById("username").value
var password= document.getElementById('password').value

// alert(username)

var server_data = [
    {"first_name": firstName,
    "last_name":lastName,
    "gender": gender,
    "age": age,
    "number": number,
    "email": email,
    "user_name":username,
    "password":password}
];

// alert(JSON.stringify(server_data))

console.log(server_data)

// alert(JSON.stringify(server_data))
// $('#addCoordinator').on('click', function(e){
    $.ajax({
        type: "POST",
        url: "/addcoordinator",
        data: JSON.stringify(server_data),
        contentType: "application/json",
        dataType: 'json',
        // alert("asd")
        success: function(data) {
          console.log("Result:");
          console.log(data);
          if (data.success){
            $("#crds").load(" #crds > *");
          }
          // $('#coordinators').html($('#coordinators',data).html());
          // $('#coordinators').load("role/coordinator/coordinators.html # coordinators");

        } 
    });
    // e.preventDefault()
// })
}


// function editCoordinatorId (){
//   var cId = document.getElementById("cname").value
//   alert(cId)
//   $.ajax({
//       type: "GET",
//       url: "coordinator/"+cId,
//       success: function(responses) {
//         console.log(responses.first_name);
//         alert(responses.first_name)
//         // window.location.href = "http://www.w3schools.com"


//       // document.getElementById("ppp").innerHTML = data.first_name;
//       // $("#cname").val(data.name)
//       $("#editfirst_name").val("responses.first_name")

//       window.location.href = "/onecoordinator"
//       console.log(responses.first_name);
//       alert(responses.last_name)
//       // return data

//       } 

//   });
// }

function editCoordinatorData(){
var cname = document.getElementById("coname").value
// alert(cname)
var gender = document.getElementById("editcogender").value

var first_name = document.getElementById("editcofirst_name").value
var last_name = document.getElementById("editcolast_name").value
var number = document.getElementById("editconumber").value
var email = document.getElementById("editcoemail").value
var age = document.getElementById("editcoage").value
var status = document.querySelector('input[name="editcostatus"]:checked').value

// var password= document.getElementById('editpassword').value
// var gender = document.querySelector('input[name="editgender"]:checked').value
// alert(cname)

var editCo_data = [
    {
    "first_name": first_name,
    "last_name": last_name,
    "number": number,
    "age":age,
    "email": email,
    "gender": gender,
    "active":status
    }
];

// alert(JSON.stringify(editCo_data))

// $('#editCoordinator').on('click')(function(e){
    $.ajax({
        type: "PUT",
        url: "/editcoordinator/"+cname,
        data: JSON.stringify(editCo_data),
        contentType: "application/json",
        dataType: 'json',
        success: function(result) {
          console.log("Result:");
          console.log(result);
        //   $('#coordinators').load(location.href +  ' #coordinators');
        $('#coordinators').load(location.href +  ' #coordinators');

        } 
    });
    // e.preventDefault()
// })
}


// function editCoordinatorData (){
//   $.ajax({
//       type: "GET",
//       url: "onecoordinator",
//       success: function(responses) {
//         console.log("Result:");
//         alert(responses)
//         $("#editfirst_name").val(data.first_name)    
//       return data
//       } 
//   });
// }


// ====================== End coordinator functions ====================



// ====================== researcher functions ====================



function addResearcher(){

// alert("fun") 

var firstName = document.getElementById("firstName").value

var lastName = document.getElementById("lastName").value
var fullName = firstName +" "+ lastName
var gender = document.querySelector('input[name="gender"]:checked').value;
var age = document.getElementById("dob").value 
var number = document.getElementById("number").value
var email = document.getElementById("email").value
var username = document.getElementById("username").value
var password= document.getElementById('password').value

// alert(username)

var researcher_data = [
    {"first_name": firstName,
    "last_name":lastName,
    "gender": gender,
    "age": age,
    "number": number,
    "email": email,
    "user_name":username,
    "password":password}
];

// alert(JSON.stringify(server_data))

console.log(researcher_data)

// alert("sss")
// $('#addCoordinator').on('click', function(e){
    $.ajax({
        type: "POST",
        url: "/addresearcher",
        data: JSON.stringify(researcher_data),
        contentType: "application/json",
        dataType: 'json',
        // alert("asd")
        success: function(data) {
          console.log("Result:");
          console.log(data);
          if (data.success){
            $("#crds").load(" #crds > *");
          }
        //   $('#coordinators').html($('#coordinators',data).html());
            // $('#coordinators').load("role/coordinator/coordinators.html # coordinators");

        } 
    });
    // e.preventDefault()
// })
}



function editResearcherData(){
var rname = document.getElementById("rename").value
// alert(rname)
// var gender = document.getElementById("editcogender").value

var first_name = document.getElementById("editrefirst_name").value
var last_name = document.getElementById("editrelast_name").value
var number = document.getElementById("editrenumber").value
var email = document.getElementById("editreemail").value
var age = document.getElementById("editreage").value
var status = document.querySelector('input[name="editrestatus"]:checked').value
var gender = document.getElementById("editregender").value

// var password= document.getElementById('editpassword').value
// var gender = document.querySelector('input[name="editgender"]:checked').value
// alert(cname)

var editRe_data = [
    {
    "first_name": first_name,
    "last_name": last_name,
    "number": number,
    "age":age,
    "email": email,
    "gender": gender,
    "active":status
    }
];

// alert(JSON.stringify(editCo_data))

// $('#editCoordinator').on('click')(function(e){
    $.ajax({
        type: "PUT",
        url: "/editresearcher/"+rname,
        data: JSON.stringify(editRe_data),
        contentType: "application/json",
        dataType: 'json',
        success: function(result) {
          console.log("Result:");
          console.log(result);
        //   $('#coordinators').load(location.href +  ' #coordinators');
        // $('#coordinators').load(location.href +  ' #coordinators');

        } 
    });
    // e.preventDefault()
// })
}


// ====================== End researcher functions ====================




// ====================== Studyinvestigator functionalities ====================

function addInvestigator(){

// alert("fun") 

var firstName = document.getElementById("firstName").value
var lastName = document.getElementById("lastName").value
var fullName = firstName +" "+ lastName
var gender = document.querySelector('input[name="gender"]:checked').value;
var age = document.getElementById("dob").value 
var number = document.getElementById("number").value
var email = document.getElementById("email").value
var username = document.getElementById("username").value
var password= document.getElementById('password').value

// alert(username)

var investigator_data = [
    {"first_name": firstName,
    "last_name":lastName,
    "gender": gender,
    "age": age,
    "number": number,
    "email": email,
    "user_name":username,
    "password":password}
];

// alert(JSON.stringify(server_data))

console.log(investigator_data)

// alert("sss")
// $('#addCoordinator').on('click', function(e){
    $.ajax({
        type: "POST",
        url: "/Addstudyinvestigator",
        data: JSON.stringify(investigator_data),
        contentType: "application/json",
        dataType: 'json',
        // alert("asd")
        success: function(data) {
          console.log("Result:");
          console.log(data);
          if (data.success){
            $("#crds").load(" #crds > *");
          }
        //   $('#coordinators').html($('#coordinators',data).html());
            // $('#coordinators').load("role/coordinator/coordinators.html # coordinators");

        } 
    });
    // e.preventDefault()
// })
}



function editInvestigatorData(){
var iname = document.getElementById("inname").value
// alert(iname)
// var gender = document.getElementById("editcogender").value

var first_name = document.getElementById("editinfirst_name").value
var last_name = document.getElementById("editinlast_name").value
var number = document.getElementById("editinnumber").value
var email = document.getElementById("editinemail").value
var age = document.getElementById("editinage").value
var status = document.querySelector('input[name="editinstatus"]:checked').value
var gender = document.getElementById("editingender").value

// var password= document.getElementById('editpassword').value
// var gender = document.querySelector('input[name="editgender"]:checked').value
// alert(cname)

var editIn_data = [
    {
    "first_name": first_name,
    "last_name": last_name,
    "number": number,
    "age":age,
    "email": email,
    "gender": gender,
    "active":status
    }
];

// alert(JSON.stringify(editCo_data))

// $('#editCoordinator').on('click')(function(e){
    $.ajax({
        type: "PUT",
        url: "/Editstudyinvestigator/"+iname,
        data: JSON.stringify(editIn_data),
        contentType: "application/json",
        dataType: 'json',
        success: function(result) {
          console.log("Result:");
          console.log(result);
        //   $('#coordinators').load(location.href +  ' #coordinators');
        // $('#coordinators').load(location.href +  ' #coordinators');

        } 
    });
    // e.preventDefault()
// })
}

// ====================== End Studyinvestigator functionalities ====================



// ======================  Location functionalities ====================


function addLocation(){

  var panchayat = document.getElementById("panchayat").value
  var village = document.getElementById("village").value
  var shg = document.getElementById("shg").value 
  var arm = document.querySelector('input[name="locationarm"]:checked').value;
  var locCo = document.getElementById("locCoordinator").value
  var locRe = document.getElementById("locResearcher").value

  var location_data = [
      {"panchayat": panchayat,
      "village":village,
      "shg": shg,
      "arm": arm,
      "coordinator": locCo,
      "researcher": locRe,
    }
  ];

      $.ajax({
          type: "POST",
          url: "/Addlocation",
          data: JSON.stringify(location_data),
          contentType: "application/json",
          dataType: 'json',
          success: function(data) {
            console.log(data);
          } 
      });
      $('#addLocation').modal('hide');

}

// ====================== End location functionalities ====================


function enableEditList(name){
  var btnId = name
  // alert(name)
  var a = document.getElementById("editB"+name).getAttribute('value');
  var x = document.getElementById("side_edit"+name);
  var y = document.getElementById("full_edit"+name);
  var z = document.getElementById("loc-edit-dis"+name);
  // alert(a)
  if(name == a){
    // alert("aaa")
    if (x.style.display === "block") {
      x.style.display = "none";
      y.style.display="block";
      z.style.display="none";
    } else {
      x.style.display = "block";
      y.style.display="none";
      z.style.display="block"
    }
  }
  else if(name != a){
    x.style.display = "none";
    y.style.display="none";
    z.style.display="none";
  }
 
 
}






function addcoordinatorCloseModal(){
$('#addcoordinator').modal('hide');
}

function addResearcherCloseModal(){
$('#addresearcher').modal('hide');
}

function addInvestigatorCloseModal(){
$('#addInvestigator').modal('hide');
}


// ============== Start Survey functions=====================


function addSurvey(){

const cycleElements = Array.from(document.getElementsByClassName("cycles"))
const filledbyElements = Array.from(document.getElementsByClassName("filledBy"))
const daysElements = Array.from(document.getElementsByClassName("days"))
const plusElements = Array.from(document.getElementsByClassName("plus"))
const minusElements = Array.from(document.getElementsByClassName("minus"))
const groupElements = Array.from(document.getElementsByClassName("group"))


  console.log(cycleElements);
  var sur_name = []
  var cycleData= []
  var filledData = []
  var daysData = []
  var plusData = []
  var minusData = []
  var groupData = []

  for(var i = 0; i < cycleElements.length; i++) {
      console.log(cycleElements[i].value)
      cycleData.push(cycleElements[i].value)
  }

  for(var i = 0; i < filledbyElements.length; i++) {
    console.log(filledbyElements[i].value)
    filledData.push(filledbyElements[i].value)
  }

  for(var i = 0; i < daysElements.length; i++) {
      console.log(daysElements[i].value)
      daysData.push(daysElements[i].value)
  }
  sur_name
  for(var i = 0; i < plusElements.length; i++) {
    console.log(plusElements[i].value)
    plusData.push(plusElements[i].value)
  }

  for(var i = 0; i < minusElements.length; i++) {
    console.log(minusElements[i].value)
    minusData.push(minusElements[i].value)
  }

  for(var i = 0; i < groupElements.length; i++) {
    console.log(groupElements[i].value)
    groupData.push(groupElements[i].value)
  }

  sur_name = document.getElementById("sur_name").value

// var cycles = document.getElementById("cycles").value;
// var filled = document.getElementById("filledBy").value;
// var days = document.getElementById("days").value
// var plus = document.getElementById("plus").value
// var minus = document.getElementById("minus").value
// var group = document.getElementById("group").value

var survey_data = [{
  "survey_name": sur_name,
  "cycles":cycleData,
  "filled_by": filledData,
  "days": daysData,
  "plus": plusData,
  "minus":minusData,
  "group": groupData
}]

alert(JSON.stringify(survey_data))

$.ajax({
  type: "POST",
  url: "/Addsurvey",
  data: JSON.stringify(survey_data),
  contentType: "application/json",
  dataType: 'json',
  // alert("asd")
  success: function(data) {
    console.log("Result:");
    console.log(data);
    // if (data.success){
    //   $("#crds").load(" #crds > *");
    // }
  //   $('#coordinators').html($('#coordinators',data).html());
      // $('#coordinators').load("role/coordinator/coordinators.html # coordinators");

  } 
});

}


function editSurveyModal(name){
// document.getElementById("surveyName").value = result.module_number;
// var filled_by = document.getElementById("filledBy").value
// var survey_name = document.getElementById("surveyName").value
// var survey_name = document.getElementById("surveyName").value


$.ajax({
  type: "GET",
  url: "/survey/"+name,
  // data: JSON.stringify(location_data),
  // contentType: "application/json",
  // dataType: 'json',
  success: function(result) {
    console.log(result)
    document.getElementById("surveyName").value = result.survey_name;
    document.getElementById("filledBy").value = result.filled_by;
    document.getElementById("days").value = result.days;
    document.getElementById("plus").value = result.plusdays;
    document.getElementById("minus").value = result.minusdays;
    document.getElementById("editgroup").value = result.group1;
    document.getElementById("updatesurveybutton").value = result.sur_ins_id;
    if (result.active == 'yes'){
      document.getElementById("editSurveyActive").checked = true;
    }
    else{
      document.getElementById("statusDisabled").checked = true;
    }
  }

});
}

function updateSurvey(){
var survey_name = document.getElementById("surveyName").value;
var filled_by = document.getElementById("filledBy").value;
var survey_days = document.getElementById("days").value;
var survey_plus = document.getElementById("plus").value;
var survey_minus = document.getElementById("minus").value;
var survey_group = document.getElementById("editgroup").value;
var status = document.querySelector('input[name="editSurveyStatus"]:checked').value;
var id = document.getElementById("updatesurveybutton").value;

alert(id)

var server_data = [{
  "survey_name" : survey_name,
  "filled_by" : filled_by,
  "days" : survey_days,
  "plusdays" : survey_plus,
  "minusdays" : survey_minus,
  "group1" : survey_group,
  "active" : status

}];




$.ajax({
  type: "PUT",
  url: "/editsurvey/"+id,
  data: JSON.stringify(server_data),
  contentType: "application/json",
  dataType: 'json',
  // alert("asd")
  success: function(data) {
    console.log("Result:");
    console.log(data);

  } 
});
$("#editSurvey").modal('hide');
}


// ============== End Survey functions=====================



// ========== Start Question functionalities ===============


function AddQuestion(){
// alert("qqq")
// // var english_question = document.getElementById("english-question").value;
// // alert(english_question)

// // var kannada_question = document.getElementById("kannada-question").value;
// // var question_number = document.getElementById("question-number").value;
// // var question_branch = document.getElementById("question-branch").value;
// // var question_section = document.getElementById("question-section").value;
// // var question_sectionName = document.getElementById("question-sectionName").value;
// // var type = document.querySelector('input[name="type"]:checked').value;

// // const engQuesElements = Array.from(document.getElementsByClassName("ques_e"))
// // const kanQuesElements = Array.from(document.getElementsByClassName("ques_k"))

// // const w_eElements = Array.from(document.getElementsByClassName("w_e"))
// // const k_eElements = Array.from(document.getElementsByClassName("w_k"))

// // const ob_eElements = Array.from(document.getElementsByClassName("ob_e"))
// // const ob_kElements = Array.from(document.getElementsByClassName("ob_k"))



// // var quesEnData = []
// // var quesKaData = []

// // var w_eData = []
// // var w_kData = []

// // var ob_eData = []
// // var ob_kData = []


// // for(var i = 0; i < engQuesElements.length; i++) {
// //     console.log(engQuesElements[i].value)
// //     quesEnData.push(engQuesElements[i].value)
// // }

// // for(var i = 0; i < kanQuesElements.length; i++) {
// //   console.log(kanQuesElements[i].value)
// //   quesKaData.push(kanQuesElements[i].value) 
// // } 

// // for(var i = 0; i < w_eElements.length; i++) {
// //   console.log(w_eElements[i].value)
// //   w_eData.push(w_eElements[i].value)
// // }

// // for(var i = 0; i < k_eElements.length; i++) {
// //   console.log(k_eElements[i].value)
// //   w_kData.push(k_eElements[i].value)
// // }

// // for(var i = 0; i < ob_eElements.length; i++) {
// //   console.log(ob_eElements[i].value)
// //   ob_eData.push(ob_eElements[i].value)
// // }

// // for(var i = 0; i < ob_kElements.length; i++) {
// //   console.log(ob_kElements[i].value)
// //   ob_kData.push(ob_kElements[i].value)
// // }

// // var status = document.querySelector('input[name="ques_status"]:checked').value;
// audiovar = request.files['eng_audio']
// alert("audio")
// alert(audiovar)
// // alert(status)

// var questionData = [{
//   "survey_id": "SUR0001",
//   "que_number":question_number,
//   "que_e": english_question,
//   "que_k": kannada_question,
//   "que_branch": question_branch,
//   "section": question_section,
//   "section_name": question_sectionName,
//   "opttype":type,
//   "opt":"opt",
//   "opt_e":quesEnData,
//   "opt_k":quesKaData,
//   "opt_sb":ob_eData,
//   "opt_w":w_eData
// }]

// alert(JSON.stringify(questionData))


// $.ajax({
//   type: "POST",
//   url: "/Addquestion",
//   data: JSON.stringify(questionData),
//   contentType: "application/json",
//   dataType: 'json',
//   enctype: 'multipart/form-data',

//   // alert("asd")
//   success: function(data) {
//     console.log("Result:");
//     console.log(data);

//   } 
// });
}

function editSurveyQuestion(){

  var sur_ques_id = document.getElementById("").value
  alert("editSurveyQuestion")

  $.ajax({
    type: "GET",
    url: "/Addquestion/"+sur_ques_id,
    success: function(data) {
      console.log("Result:");
      console.log(data);
  
    } 
  });

}

function editSurQuestion(name){
  alert(name)
  $.ajax({
    type: "GET",
    url: "/editquestion//"+name,
    success: function(data) {
      console.log("Result:");
      console.log(data);
  
    } 
  });
  
}

// ========== End Question functionalities ===============

// =============Module mapping functionalities ==============

// function addModuleMapping(){
//   var sur_name = document.getElementById("survey_name").value
//   var sur_desc = document.getElementById("survey_description").value
//   var sur_min = document.getElementById("score_min").value
//   var sur_max = document.getElementById("score_max").value
//   var instance = document.getElementById("instance").value
//   const weekElements = Array.from(document.getElementsByClassName("add-week"))

//   var weekData = []

//   for(var i = 0; i < weekElements.length; i++) {
//     console.log(weekElements[i].value)
//     weekData.push(weekElements[i].value)
//   }

// }





function editModuleMapping(){
  var PkId = document.getElementById("updModule").value 
    $.ajax({
      type: "GET",
      url: "/Modulemapping/"+PkId,
      contentType: "application/json",
      dataType: 'json',
      success: function(result) {
          document.getElementById("edit_survey_name").value = result.survey_name;
          document.getElementById("edit_survey_description").value = result.description;
          document.getElementById("edit_score_min").value = result.min_score;
          document.getElementById("edit_score_max").value = result.max_score;
          document.getElementById("edit_instance").value = result.survey_instance_days;
          document.getElementById("edit_week").value = result.week_no;
          document.getElementById("edit-week-interval").value = result.interval1
          if (result.active == 'yes'){
            document.getElementById("statusActive").checked = true;
        }
        else{
            document.getElementById("statusInactive").checked = true;
        }


// active: "yes"
// description: "Level 1"
// interval1: "0"
// max_score: "5"
// min_score: "0"
// module_no: "[1a1,1a2]"
// name: "MOD_MAP_1"
// survey_instance_days: "[0,180]"
// survey_name: "SUS2"
// survey_pri_id: "SUR0002"
// week_no: "1"

      }
    });
}



function updateModuleMapping(){
  var PkId = document.getElementById("updModule").value 
  // var edited_survey_name = document.getElementById("edit_survey_name").value
  // var edited_description = document.getElementById("edit_survey_description").value
  // var edited_min_score = document.getElementById("edit_score_min").value
  // var edited_max_score = document.getElementById("edit_score_max").value
  // var edited_instance = document.getElementById("edit_instance").value
  // var edited_week = document.getElementById("edit_week").value
  // var edited_week_interval = document.getElementById("edit-week-interval").value
  // var edited_status = document.querySelector('input[name="updatedMappingStatus"]:checked').value;
  alert(PkId)
  // var server_data = [{
  //   "survey_name" : edited_survey_name,
  //   "description" : edited_description,
  //   "min_score" : edited_min_score,
  //   "max_score" : edited_max_score,
  //   "survey_instance_days" : edited_instance,
  //   "week_no" : edited_week,
  //   "interval1" : edited_week_interval,
  //   "active" : edited_status
  // }];
//   $.ajax({
//     type: "POST",
//     url: "/editlocation/"+name,
//     data: JSON.stringify(server_data),
//     contentType: "application/json",
//     dataType: 'json',
//     success: function(data) {
//       console.log(data);
//       $("#locationList").load(document.url+" #locationList");
//     } 
// });
// $('#addLocation').modal('hide');


}


function UpdateQuestion(){
  alert("iiugkj")
  
  var num_of_options = document.getElementById("no_option").value
  alert(num_of_options)

  for (var i=0;i<num_of_options;i++){
    var a  = document.getElementById("i").value
    // alert(i)
  }



  alert(a)
  alert(b)
  alert(c)
  console.log(a)
  console.log(b)


}